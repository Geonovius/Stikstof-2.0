Toelichting bij emissiebestanden:

NH3_17_nl.brn		- Alle Nederlandse NH3-bronnen voor het jaar 2017 per GCN-sector
NH3_2016_SNAP.brn	- Alle buitenlandse NH3-bronnen voor het jaar 2016 per SNAP-sector
NH3_b_nos-ncp.brn	- Alle zee NH3-bronnen
NOx_17_nl.brn		- Alle Nederlandse NOx-bronnen voor het jaar 2017 per GCN-sector
NOx_2016_SNAP.brn	- Alle buitenlandse NOx-bronnen voor het jaar 2016 per SNAP-sector
NOx_16_nos-ncp.brn	- Alle zee NOx-bronnen voor het jaar 2016



