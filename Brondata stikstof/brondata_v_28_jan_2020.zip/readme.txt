
Hierbij een korte beschrijving hoe OPS te downloaden, bestanden te installeren en het model te draaien.

�	Download de laatste versie van het OPS model inclusief GUI van de RIVM website. Dit is openbaar en voor iedereen te downloaden.
�	Installeer het OPS model op een lokaal systeem.
�	Voeg de bestanden met de meteo voor het jaar 2018 uit het zipbestand met_OPS_GCN2019.zip in de geinstalleerde omgeving toe aan de folder �meteo�   
�	Plaats de bestanden uit het zipbestand brn_OPS_GCN2019.zip ergens op het lokale systeem.
�	Plaats de bestanden uit het zipbestand ctr_OPS_GCN2019.zip ergens op het lokale systeem.
�	In het ctr zipbestand zitten twee ctr-bestanden. Een voor het uitvoeren van de NH3 berekeningen en een voor NOx
�	Wat in deze ctr-bestanden nog moet gebeuren het aanpassen van de paden naar de juiste lokaties.
�	Daarna kan een ctr-bestand geladen worden in de OPS-GUI of vanaf de commandline een run worden opgestart

WdV, 7 januari 2020